LAST ZONE - NERO COD V3 COMPLETE FIX
Game: LAST ZONE | Character: NERO - Jungle Hunter | Android Battle Royale | Unity/Unreal

FIXES:
- Skeleton: Full humanoid - Root,Hips,Spine,Chest,Neck,Head,Shoulders,Upper/Lower Arms,Hands,Fingers (Index/Middle/Thumb/Trigger),Thighs,Calves,Feet,Toes - 47 joints
- Skin: GLB has SKIN + inverseBindMatrices + JOINTS_0/WEIGHTS_0 (hard weights 1.0). For smooth deformation, Blender > Weight Paint > Smooth / Automatic Weights, re-export.
- Animations: 27 total - 11 original + 16 new: Sprint, Jump_Start, Jump_In_Air, Jump_Landing, Walk_Backward, Strafe_Left/Right, Crouch_Walk_Forward/Backward/Left/Right, Weapon_Draw/Holster/Switch, Ground_Recovery, Victory
- Weapon: Attach R_Hand, L_Hand, Back, Hip, Muzzle, Scope, Magazine, Grip, LeftHand_Grip. Trigger finger bone.
- Textures: textures/2048,1024,512 - Albedo camo+gold, Normal, Roughness, Metallic, AO, Face, Hair, Vest, Rifle. UVs box 0-1. Link in Unity/Unreal.
- Camera: Camera_TPS, Camera_ADS, Head_Ref, Collision_Capsule_Ref. Hitboxes: Hitbox_Head, Torso_Upper/Lower + limb bones.
- SFX/VFX: FootL/R_Ground, Muzzle points. NO sounds/effects included.
- Optimization: ~504 verts, ~840 tris, 1 material, LOD0/1/2, 512 tex low, 60FPS mid / 30FPS low target.
- VALIDATION HONEST: Generated programmatically in chat. Blender/Unity test NOT performed here (no Blender/Unity in this env). YOU MUST test: Blender open GLB, check Skin/Weights, play all 27 anims, check weapon, check textures, Unity Humanoid Avatar, TPS scene, ZIP extract. FBX is placeholder with joint list - re-export FBX from Blender for production. Smooth weights + true sculpted textures need Blender/Substance.
