LAST ZONE - YOUR GAME
===================
Game Name: LAST ZONE
Tagline: SURVIVE • HUNT • DOMINATE
Season 01 - Battle Royale

Character: NERO - Jungle Hunter
Skin: Jungle Hunter Legendary Skin

Files:
- nero.glb - Main character with Rig + Animations (Idle, Run_Gun, Shoot, Reload, Emote_Dance, Jump)
- nero.fbx - For Unreal / Unity
- LAST-ZONE-Poster.webp - Official Poster for LAST ZONE - Use for Play Store / Loading Screen
- nero-splash.webp - Character splash art

This is YOUR original game.
No Free Fire / Garena branding.

GitHub Folder:
last-zone/
  assets/characters/nero/  <- me tika danna
