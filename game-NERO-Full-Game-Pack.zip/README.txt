NERO JUNGLE HUNTER - FULL GAME PACK
=====================================

Files in this pack:
- nero.glb  -> Unity / Godot / Three.js / Blender (MAIN FILE)
- nero.fbx  -> Unreal / Unity / Blender
- nero.obj + nero.mtl -> Blender backup
- nero-reference.webp -> Reference image

HOW TO USE IN UNITY:
1. Unity > Assets > Import New Asset > nero.glb or nero.fbx danna
2. Character eka Scene ekata drag karanna
3. Mixamo eken animation danna (mixamo.com - free)

HOW TO USE IN GODOT:
1. Godot > Import > nero.glb danna
2. CharacterBody3D ekata add karanna

HOW TO USE IN BLENDER:
1. File > Import > nero.glb / nero.fbx
2. Rig karanna / FBX export karanna

GITHUB FOLDER:
my-game/
  assets/characters/nero/  <- me folder eka okkoma danna
  README.md

FBX NOTE: Me FBX eka low-poly T-Pose model ekak. Blender eken open karala detail add karanna puluwan.
GLB eka thama hoda ma eka game ekata.
