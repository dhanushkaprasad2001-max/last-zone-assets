LAST ZONE - COD STYLE PACK
Game: LAST ZONE - Original Battle Royale
Style: Realistic Tactical / COD-style (NOT Call of Duty, original game)

Files:
- nero-cod.glb - Main, Rig + 11 COD-style animations
- nero.fbx
- LAST-ZONE-COD-Poster.webp

Animations:
COD_Idle_Tactical, COD_Walk, COD_Run_Tactical, COD_ADS_Aim, COD_Shoot_ADS, COD_Reload_Tactical, COD_Crouch, COD_Slide, COD_Death, COD_Hit_Reaction, COD_Emote

Weapon Attach:
- Weapon_Attach_R_Hand (Right Hand)
- Weapon_Attach_Back (Back - for second weapon)
- Camera_ADS (for ADS camera)

Optimization:
Verts ~650, Tris ~950 - Low for mobile, High quality look via materials.
Use 1 material, 1024 texture for high phones, 512 for low phones.
Unity: URP, 1 Directional Light, Shadows Low.
