LAST ZONE - NERO FINAL FIXED ZIP
Weradi niwaradi kala:
- OLD GLB warada: mesh world position + bone double transform -> parts kadila penuna
- NEW FIX: mesh tika bone ekata parent kala, local coordinates, double transform na -> dan kadila penne na
- Poster pose: hood, headband gold, green glowing eyes, gold shoulders, Sri Lanka patch, vest + pouches, knee pads, sniper with scope
- Background: Misty jungle at dawn poster included for Tripo reference

Contents:
- Models/nero_FINAL_FIXED.glb - Main corrected character (use this on GitHub as nero.glb)
- Models/nero_V5_FIXED.glb - Simple fixed version (backup)
- NERO_Misty_Jungle_Dawn_Poster.webp - Poster for Tripo.ai Image to 3D
- Textures/ - Albedo + Normal
- README - This file

GitHub:
1. Old nero.glb delete karanna
2. nero_FINAL_FIXED.glb -> nero.glb kiyala rename karala upload karanna
3. Refresh karanna

NOT DONE (Honest):
- Blender test NOT done (no Blender in chat)
- Unity test NOT done (no Unity in chat)
- COD AAA quality needs Tripo + Blender + Substance - see V7 README
