LAST ZONE - NERO - JUNGLE HUNTER LEGENDARY SKIN
PRE-PRODUCTION PACKAGE v0.1 - NOT A FINAL GAME-READY BUILD

HONEST STATUS - READ THIS FIRST:
This environment cannot create a real AAA-quality skinned FBX, Blender .blend with finger skin weights, or keyframed animations. I have NOT created fake/empty .fbx/.blend files and I am NOT claiming this character is finished.
What IS in this ZIP is real and usable: a locked character bible, procedural texture maps, rig/animation specification, and Unity/Unreal import checklists.

WHAT REMAINS TO BE COMPLETED IN BLENDER / MAYA (by a 3D artist):
1. High-poly sculpt from reference (front view only supplied - back/side are ASSUMPTIONS, see SPEC)
2. Retopology LOD0 ~55k tris, LOD1 ~28k, LOD2 ~14k, LOD3 ~7k for mobile
3. UV unwrap 0-1, no overlap on face/hands
4. Skin weights - fingers, shoulders, hips, knees - test with animation set below
5. Rig: Humanoid + finger bones + weapon bones (see SPEC)
6. Keyframe all 22 animations listed, export as separate FBX clips
7. Final PBR textures painted from this base - these PNGs are BASE / BLOCKOUT, not final painted textures
8. QA re-import in Unity/Unreal, test weapon grips, clipping, mobile perf

REFERENCE LOCK - FROM SUPPLIED IMAGE ONLY:
Name: NERO | Class: Sniper / Stealth | Origin: Sri Lanka | Stats: Stealth 95, Precision 92, Survival 90
Face: South Asian male, short black curly hair, short beard/moustache, intense expression, glowing green eyes (EMISSIVE - gameplay VFX, not natural eye colour)
Headgear: Dark olive headband with gold leaf emblem, tactical headset with mic, ear cups olive/black with gold detail
Jacket: Hooded tactical jacket, dark jungle camo (black/olive with fern leaf print), gold ornate filigree trim on chest, shoulders, cuffs, gold shoulder epaulette (left - lion-like crest), Sri Lanka flag patch + SRI LANKA tab on left chest, gold geometric patch on right upper arm
Torso: Black undershirt, chest rig / harness with gold buckles, pouches
Pants: Dark jungle camo cargo pants, fern print, thigh straps with gold buckles, knee pads camo/black
Boots: High tactical boots, black/olive with gold trim
Gloves: Fingerless / tactical gloves, camo
Weapon: Bolt-action sniper rifle, black with gold filigree, glowing green energy strip + green scope lens glow, long barrel, muzzle brake, bipod folded / extended not visible
Pose in reference: Standing, rifle held across body, left hand on foregrip, right hand near trigger - THIS IS THE REFERENCE POSE, NOT T-POSE. Build in A-pose, then pose to this for promo.

ASSUMPTIONS - NO BACK/SIDE VIEW SUPPLIED:
Back: Same camo + gold trim, hood down, backpack NOT assumed - do NOT add backpack unless design approves. Rear pouches mirrored.
Side: Same knee pads, thigh pouches both sides.
Underside / feet soles: Plain black tread - artist to design.
If any assumption conflicts with your design intent, change SPEC before sculpting.

RIG SPEC:
Hierarchy: Root > Hips > Spine > Spine1 > Chest > Neck > Head > Jaw, Eyes L/R
Arms: Shoulder > UpperArm > Forearm > Hand > Thumb(3) + Index/Middle/Ring/Pinky (3 each)
Legs: Thigh > Shin > Foot > Toes
Weapon bones: Weapon_Root, Weapon_Muzzle, Weapon_Mag, Weapon_Scope, HandIK_L, HandIK_R, FootIK_L, FootIK_R
Blendshapes: Blink, Eye_L/R Look, Jaw_Open, Brow_Frown, Mouth_Smile, Mouth_Frown, Hit_Grimace

ANIMATIONS (22, separate clips, 30fps, loop where noted):
Idle(120f loop), Walk(32f loop), Run(24f loop), Sprint(20f loop), Jump(30f), Fall(loop), Landing(20f), Crouch(1f pose + loop), CrouchWalk(32f loop), Prone, Aim, HipFire, ADS, Shoot(12f), Reload(60f sniper), WeaponSwitch(30f), Melee(25f), GrenadeThrow(40f), HitReaction(18f), Death(60f), Victory(120f), Emote_JungleHunter(120f)
Transitions: Idle->Walk 0.15s, Walk->Run 0.2s, Any->Hit 0.05s, Shoot->Reload interrupt allowed at mag empty.

UNITY IMPORT: FBX, Scale 0.01, Y-up, Humanoid Rig, Avatar from NERO, Root Motion OFF for locomotion, ON for Death/Victory. Materials: URP/HDRP Lit, BaseColor sRGB, Normal OpenGL, Roughness/Metallic packed if needed.
UNREAL IMPORT: FBX, Scale 1.0 cm, Mannequin-compatible skeleton naming if retargeting, Import Normals, Materials: BaseColor, Normal (flip G), Roughness, Metallic, AO multiplied.

TEXTURES IN THIS ZIP:
NERO_*_BaseColor.png - procedural camo blockout, 1024px, replace with hand-painted 2048px final
NERO_Body_Normal/Roughness/Metallic/AO/Emission - flat blockout maps, for pipeline testing only
Emission: Green glow areas only - eyes, scope lens, rifle energy strip. Keep emission strength 2.0-3.0 in engine.

QA CHECKLIST (do not ship until all pass):
[ ] Re-import FBX, no missing meshes
[ ] UV 0-1, no stretching on face
[ ] Finger weights: no candy-wrapper on thumb/index
[ ] Rifle grip: both hands contact, no clipping through jacket
[ ] All 22 anims play, no foot sliding >5cm
[ ] LOD switch at 15m / 30m / 60m, no pop on silhouette
[ ] Mobile: LOD0 <60k tris, draw calls <12, texture memory <64MB
